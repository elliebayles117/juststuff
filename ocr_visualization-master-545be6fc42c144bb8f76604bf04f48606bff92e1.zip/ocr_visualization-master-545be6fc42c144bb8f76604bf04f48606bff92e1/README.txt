This is an R Shiny webapp I threw together for my OCR visualization code,
so that it's interactive rather than run from the command line.
It has some issues which I am working on:  
    Image does not dynamically resize  
    Doesn't work with images that are too small  
    There may be a file size limit  
    Doesn't support phrase search  
    Issues with text size and overlapping text when trying to render translated output  
    Can't go from one button to the other, you have to refresh the app  

The first time you run it you will need to install some R packages,
run the following line in your R console:  
install.packages("shiny","shinythemes","shinyjs","stringr","png","jpg","tiff","raster","plotrix","zoo")  

If you are using RStudio you can run the app by pressing the "Run App" button at the top.  
If you are using an R console you can run the app with the command runApp('ocr_visualization')
I included an example image of text and its corresponding HOCR in exampledata
