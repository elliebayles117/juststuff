#################################
##### OCR Visualization App #####
##### Author: Ellie Bayles ######
#################################

library(shiny)
library(shinythemes)
library(shinyjs)
library(stringr)
library(png)
library(jpeg)
library(raster)
library(tiff)
library(plotrix)
library(zoo)
options(stringsAsFactors = F)

ui <- fluidPage(
  useShinyjs(),
  theme=shinytheme("cerulean"),
  tags$style("
              body {
    -moz-transform: scale(0.6, 0.6); /* Moz-browsers */
    zoom: 0.6; /* Other non-webkit browsers */
    zoom: 60%; /* Webkit browsers */
}
              "),
  #Sidebar panel for file inputs and buttons
  sidebarLayout(
    sidebarPanel(
      titlePanel("OCR Visualization"),
      #Input image and corresponding HOCR files
      fileInput("imgfile", "Choose an image file
                (jpg, png, or tiff)",
                multiple = FALSE,
                accept = c("image/png",
                            "image/jpeg",
                            "image/tiff")),
      fileInput("hocrfile",
                "Choose the file with the corresponding
                HOCR output from Tesseract",multiple=FALSE),
      
      #this shows the visualization of
      #the translation with confidence
      actionButton("showAll","Show text with confidence"),
      helpText("If you press this button, you'll have to hit
               refresh to use the search button, I haven't
               figured out how to fix this yet."),
      hr(),
      #this finds all instances of the user input word(s)
      textInput("toFind","Words or phrases to find,
                separated by comma+space: "),
      checkboxInput("showPartial","Include partial matches"),
      actionButton("showSearch","Search for word(s)"),
      hr(),
      htmlOutput("text"),
      width=3
      ),
    
    #Main panel for output
    mainPanel(imageOutput('myPlot'),width=6)
  )
)

server <- function(input,output) {
  
  output$text<-renderUI({ HTML(paste(
    "Known issues:",
    "Image does not dynamically resize",
    "Doesn't work with images that are too small",
    "There may be a file size limit",
    "Issues with text size and overlapping text
    when trying to render translated output",
    "Can't go from one button to the other,
    you have to refresh the app",
    sep="<br/>"))
    })
  
  #Parses the HOCR using regular expressions
  parseHOCR<-function(text_hocr){
    text_hocr2<-gsub("\n","",text_hocr)
    text_hocr2<-gsub("\\s+"," ",text_hocr2)
    textlist<-unlist(strsplit(text_hocr2,split="</span>"))
    textlist<-unlist(strsplit(textlist,split="<span"))
    textlist2<-textlist[grep("class='ocrx_word'",textlist)]
    temp1<-data.frame(textlist2)
    temp2<-t(data.frame(apply(temp1,1,strsplit,
                              split="[\']")))
    parsed_frame<-data.frame(t(data.frame(strsplit(
      temp2[,6],split=";"))))
    parsed_frame<-cbind(parsed_frame,data.frame(
      sub('.','',temp2[,7])))
    rownames(parsed_frame)<-temp2[,4]
    colnames(parsed_frame)<-c("dims","conf","word")
    parsed_frame$word<-gsub('<strong>','',parsed_frame$word)
    parsed_frame$word<-gsub('</strong>','',parsed_frame$word)
    parsed_frame$word<-gsub('<em>','',parsed_frame$word)
    parsed_frame$word<-gsub('</em>','',parsed_frame$word)
    parsed_frame$word<-gsub('&quot;','"',parsed_frame$word)
    parsed_frame$word<-gsub('&#39;',"'",parsed_frame$word)
    #maybe add some more replacements
    #for common issue characters here
    parsed_frame$dims<-gsub("bbox ","",parsed_frame$dims)
    newcols<-data.frame(strsplit(parsed_frame$dims,
                                 split=" "),
                        stringsAsFactors = F)
    newcols<-data.frame(t(newcols))
    colnames(newcols)<-c("xl","yt","xr","yb")
    parsed_frame<-data.frame(cbind(parsed_frame,newcols),
                             stringsAsFactors = F)
    parsed_frame$conf<-gsub("x_wconf","",parsed_frame$conf)
    parsed_frame$xl=as.numeric(parsed_frame$xl)
    parsed_frame$yt=as.numeric(parsed_frame$yt)
    parsed_frame$xr=as.numeric(parsed_frame$xr)
    parsed_frame$yb=as.numeric(parsed_frame$yb)
    return(parsed_frame)
  }
  #just vectorizing the seq() function
  multiseq<-Vectorize(seq.default,vectorize.args=c("from"))
  
  #When you press the "show text with confidence" button
  observeEvent(input$showAll,{
    
    output$myPlot<-renderImage({
      
      #won't run without both files input
      req(input$imgfile) 
      req(input$hocrfile)
      #fixing the filepath and finding the image format
      imgfile<-input$imgfile
      imgname<-unlist(imgfile)[4]
      imgname<-normalizePath(imgname)
      suffix<-strsplit(imgname,split=".",fixed=T)[[1]][2]
      if(suffix=="png") {
        img<- readPNG(imgname,native=T)
      } else if(suffix=="jpg"|suffix=="jpeg") {
        img<- readJPEG(imgname,native=T)
      } else if(suffix=="tiff"|suffix=="tif") {
        img<- readTIFF(imgname,native=T)
      } else { #this will probably result an error
        print("Image must be in jpg, png, or tiff format")
      }
      
      #getting info about the image
      imgw=dim(img)[2] #image width in pixels
      imgh=dim(img)[1] #image height in pixels
      lgndw=imgw/10 #calculates extra space for legend
      
      # This should read in a HOCR
      hocrfile<-input$hocrfile
      hocrname<-unlist(hocrfile)[4]
      hocrname<-normalizePath(hocrname)
      text_hocr <- paste(scan(hocrname,what="character",
                              sep=NULL,quiet=T),sep=" ",
                         collapse=" ")
      
      #parses the HOCR input
      parsed_frame<-parseHOCR(text_hocr)
      
      # This renders an image of the text with
      #visualization of OCR results
      plotw<-2*imgw
      ploth<-imgh
      xmin<-0
      xmax<-plotw
      ymin<--ploth
      ymax<-0
      
      outfile<-tempfile(fileext='.tiff')
      tiff(outfile,
           res=300,height=ploth,width=(plotw+200))
      plot(NA,xlab="",ylab="",
           xlim=c(xmin,xmax+200),ylim=c(ymin,ymax),
           asp=1,xaxt='n',yaxt='n')
      rasterImage(img,xmin,ymin,xmax/2,ymax)
      ii<-cut(as.numeric(parsed_frame$conf),
              breaks=seq(0,100,10),include.lowest=T)
      colvec2<-colorRampPalette(c("red","orange",
                                  "green3"))(10)[ii]
      
      #This renders the rectangles around each word,
      #and the corresponding translation
      #one word at a time
      for(i in nrow(parsed_frame):1) {
        row=parsed_frame[i,]
        conf<-row$conf
        word<-row$word
        xl=xmin+row$xl
        yb=ymax-row$yb
        xr=xmin+row$xr
        yt=ymax-row$yt
        rect(xl,yb,
             xr,yt,border=colvec2[i],lwd=.75)
        rect(xl+imgw,yb,
             xr+imgw,yt,col=colvec2[i],border=colvec2[i])
        textbox(x=c(xl+imgw,xr+imgw),y=yt,
                textlist=word,cex=.33,
                justify="c",leading=0,box=F)
      }

      #Renders legend on the side
      colfunc <- colorRampPalette(c("green3",
                                    "orange","red"))
      legend_image <- as.raster(matrix(colfunc(10),ncol=1))
      text(x=2*imgw+lgndw, y = seq(ymin+lgndw/4,
                                   ymax-lgndw/4,l=5),
           labels = seq(0,100,l=5),cex=.5)
      rasterImage(legend_image,2*imgw,ymin+lgndw/4,
                  2*imgw+lgndw/2,ymax-lgndw/4)
      dev.off()
      list(src = outfile,
           alt = "This is alternate text")
    },deleteFile=T)
  }) 
  
  #When you press the "Search for a word" button
  toFind<-eventReactive(input$showSearch,{
    #Takes in user input here
    #Not case-sensitive
    tolower(unlist(strsplit(input$toFind,split=", ")))
  })
  output$myPlot<-renderImage({
    
    #won't run without both files input
    req(input$imgfile) 
    req(input$hocrfile)
    req(toFind)
    #fixing the filepath and finding the image format
    imgfile<-input$imgfile
    imgname<-unlist(imgfile)[4]
    imgname<-normalizePath(imgname)
    suffix<-strsplit(imgname,split=".",fixed=T)[[1]][2]
    if(suffix=="png") {
      img<- readPNG(imgname,native=T)
    } else if(suffix=="jpg"|suffix=="jpeg") {
      img<- readJPEG(imgname,native=T)
    } else if(suffix=="tiff"|suffix=="tif") {
      img<- readTIFF(imgname,native=T)
    } else { #this will probably result in an error
      print("Image must be in jpg, png, or tiff format")
    }
    
    #getting info about the image
    imgw=dim(img)[2] #image width in pixels
    imgh=dim(img)[1] #image height in pixels
    lgndw=imgw/10 #calculates extra space for legend
    
    # This should read in a HOCR
    hocrfile<-input$hocrfile
    hocrname<-unlist(hocrfile)[4]
    hocrname<-normalizePath(hocrname)
    text_hocr <- paste(scan(hocrname,what="character",
                            sep=NULL,quiet=T),
                       sep=" ",collapse=" ")
    
    #parses the HOCR input
    parsed_frame<-parseHOCR(text_hocr)
    #pulls out punctuation for better searching
    #and makes it lowercase
    parsed_frame$word<-tolower(gsub("[[:punct:]]","",
                                    parsed_frame$word)) 
    
    #Renders the original picture of the text
    #with boxes around matches to the search
    outfile<-tempfile(fileext='.tiff')
    tiff(outfile,
         res=300,height=imgh,width=imgw+200)
    plot(NA,xlab="",ylab="",
         xlim=c(0,imgw+200),ylim=c(0,imgh),
         asp=1,xaxt='n',yaxt='n')
    rasterImage(img,0,0,imgw,imgh)
    ii<-cut(as.numeric(parsed_frame$conf),
            breaks=seq(0,100,10),include.lowest=T)
    colvec2<-colorRampPalette(c("red","orange",
                                "green3"))(10)[ii]
    
    #If the "show partial matches" box is checked
    #Searches for exact matches to phrases
    #Searches for partial matches to words
    if(input$showPartial) {
      for(phrase in toFind()) {
        phrase<-unlist(strsplit(phrase, split=" "))
        #handles multi-word phrases
        if(length(phrase)>1) {
          num<-which(rollapply(parsed_frame$word,
                          length(phrase),
                          identical,
                          phrase,
                          fill = FALSE,
                          align = "left"))
          #if given phrase found at least once
          if(length(num)>0) {
            nums<-multiseq(num,length.out=length(phrase))
            row=parsed_frame[nums,]
            xl=row$xl-5
            yb=imgh-row$yb-5
            xr=row$xr+5
            yt=imgh-row$yt+5
            rect(xl,yb,xr,yt,border=colvec2[nums],lwd=1)
          }
        } else {
          nums<-which(grepl(phrase,parsed_frame$word))
          row=parsed_frame[nums,]
          xl=row$xl-5
          yb=imgh-row$yb-5
          xr=row$xr+5
          yt=imgh-row$yt+5
          rect(xl,yb,xr,yt,border=colvec2[nums],lwd=1)
        }
      }
    } else {
      #If the "show partial matches" box is unchecked
      #Checks for exact matches to the search terms
      for(phrase in toFind()) {
        phrase<-unlist(strsplit(phrase, split=" "))
        #handles multi-word phrases and single words
        num<-which(rollapply(parsed_frame$word,
                             length(phrase),
                             identical,
                             phrase,
                             fill = FALSE,
                             align = "left"))
        #if given phrase found at least once
        if(length(num)>0) {
          nums<-multiseq(num,length.out=length(phrase))
          row=parsed_frame[nums,]
          xl=row$xl-5
          yb=imgh-row$yb-5
          xr=row$xr+5
          yt=imgh-row$yt+5
          rect(xl,yb,xr,yt,border=colvec2[nums],lwd=1)
        }
      }
    }
    colfunc <- colorRampPalette(c("green3","orange","red"))
    legend_image <- as.raster(matrix(colfunc(10), ncol=1))
    text(x=imgw+150, y = seq(50,imgh-50,l=5),
         labels = seq(0,100,l=5),cex=.5)
    rasterImage(legend_image,imgw,50,imgw+50,imgh-50)
    dev.off()
    list(src = outfile,
         alt = "This is alternate text")
  },deleteFile=T)
}

# Run app
shinyApp(ui=ui, server=server)